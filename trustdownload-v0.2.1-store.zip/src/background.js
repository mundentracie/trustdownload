(() => {
  // src/lib.js
  function badgeCount(items) {
    return items.filter((it) => it && it.state === "in_progress").length;
  }
  function fileNameOf(path) {
    if (!path) return "(unknown)";
    const i = Math.max(path.lastIndexOf("/"), path.lastIndexOf("\\"));
    return i >= 0 ? path.slice(i + 1) : path;
  }
  function categoryOf(filename) {
    const ext = (filename.match(/\.([a-z0-9]{1,8})$/i) || [])[1];
    const e = (ext || "").toLowerCase();
    if (["zip", "rar", "7z", "tar", "gz", "bz2", "xz"].includes(e)) return "archive";
    if (["jpg", "jpeg", "png", "gif", "webp", "svg", "bmp", "ico"].includes(e)) return "image";
    if (["mp4", "mkv", "webm", "avi", "mov", "flv", "wmv"].includes(e)) return "video";
    if (["mp3", "wav", "ogg", "flac", "m4a", "aac"].includes(e)) return "audio";
    if (["pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "md", "csv"].includes(e)) return "doc";
    return "other";
  }
  var DEFAULT_FOLDERS = Object.freeze({
    image: "Images",
    video: "Video",
    audio: "Audio",
    doc: "Documents",
    archive: "Archives",
    other: "Other"
  });
  function safeSegment(name) {
    const s = String(name || "").replace(/[\\/:*?"<>|]/g, "").replace(/\.\.+/g, "").trim();
    return s.slice(0, 60);
  }
  function dateSegment(isoString, granularity) {
    if (!isoString) return null;
    const day = String(isoString).slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) return null;
    return granularity === "day" ? day : day.slice(0, 7);
  }
  function proSubdir(downloadItem, rules) {
    if (!rules || rules.organize === void 0 || rules.organize === "off" || rules.organize === false) return null;
    if (!downloadItem || !downloadItem.filename) return null;
    const name = fileNameOf(downloadItem.filename);
    const folders = { ...DEFAULT_FOLDERS, ...rules.folders || {} };
    const cat = categoryOf(name);
    const parts = [];
    if (rules.organize === "type" || rules.organize === "type+date") {
      const seg = safeSegment(folders[cat] || folders.other);
      if (seg) parts.push(seg);
    }
    if (rules.organize === "date" || rules.organize === "type+date") {
      const seg = dateSegment(downloadItem.startTime, rules.dateFormat);
      if (seg) parts.push(seg);
    }
    if (parts.length === 0) return null;
    return parts.filter(Boolean).join("/");
  }

  // src/background.js
  var DEFAULTS = {
    theme: "auto",
    shelf: false,
    filter: "all",
    pro: false,
    organize: "off",
    dateFormat: "month",
    folders: {}
  };
  async function getPrefs() {
    try {
      const stored = await chrome.storage.local.get(Object.keys(DEFAULTS));
      return { ...DEFAULTS, ...stored };
    } catch {
      return { ...DEFAULTS };
    }
  }
  async function setShelf(hidden) {
    try {
      await chrome.downloads.setShelfEnabled(!hidden);
    } catch {
    }
  }
  async function refreshBadge() {
    let count = 0;
    try {
      const items = await chrome.downloads.search({});
      count = badgeCount(items);
    } catch {
      count = 0;
    }
    try {
      await chrome.action.setBadgeText({ text: count > 0 ? String(count) : "" });
      await chrome.action.setBadgeBackgroundColor({ color: "#2563eb" });
    } catch {
    }
  }
  async function applyShelfPref() {
    const prefs = await getPrefs();
    await setShelf(prefs.shelf);
  }
  chrome.runtime.onInstalled.addListener(() => {
    applyShelfPref();
    refreshBadge();
  });
  chrome.runtime.onStartup.addListener(() => {
    applyShelfPref();
    refreshBadge();
  });
  for (const ev of [
    chrome.downloads.onCreated,
    chrome.downloads.onChanged,
    chrome.downloads.onErased
  ]) {
    ev.addListener(() => {
      refreshBadge();
    });
  }
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg && msg.type === "prefs-updated") {
      applyShelfPref().then(() => sendResponse({ ok: true }));
      return true;
    }
    if (msg && msg.type === "ping") {
      sendResponse({ ok: true });
    }
    return void 0;
  });
  async function rulesFor(item) {
    try {
      const stored = await chrome.storage.local.get(["pro", "organize", "dateFormat", "folders"]);
      if (!stored.pro) return null;
      return {
        organize: stored.organize || "off",
        dateFormat: stored.dateFormat || "month",
        folders: stored.folders || {}
      };
    } catch {
      return null;
    }
  }
  chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
    rulesFor(item).then((rules) => {
      if (!rules) {
        suggest();
        return;
      }
      const subdir = proSubdir(item, rules);
      if (!subdir) {
        suggest();
        return;
      }
      const name = fileNameOf(item.filename);
      suggest({ filename: `${subdir}/${name}`, conflictAction: "uniquify" });
    }).catch(() => suggest());
    return true;
  });
})();
