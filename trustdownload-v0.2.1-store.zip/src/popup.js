(() => {
  // src/lib.js
  function formatBytes(n) {
    if (typeof n !== "number" || !isFinite(n) || n < 0) return "";
    if (n < 1024) return `${n} B`;
    const units = ["KB", "MB", "GB", "TB"];
    let v = n;
    let i = -1;
    do {
      v /= 1024;
      i++;
    } while (v >= 1024 && i < units.length - 1);
    return `${v >= 100 ? Math.round(v) : v.toFixed(1)} ${units[i]}`;
  }
  function dayKey(isoString) {
    if (!isoString) return "unknown";
    return String(isoString).slice(0, 10);
  }
  function bucketOf(item) {
    if (!item || typeof item !== "object") return "other";
    const s = item.state;
    if (s === "in_progress") return "active";
    if (s === "complete") return "done";
    if (s === "interrupted") return item.error ? "failed" : "stopped";
    return "other";
  }
  function applyFilter(items2, filter) {
    if (filter === "all") return items2;
    return items2.filter((it) => bucketOf(it) === filter);
  }
  function fileNameOf(path) {
    if (!path) return "(unknown)";
    const i = Math.max(path.lastIndexOf("/"), path.lastIndexOf("\\"));
    return i >= 0 ? path.slice(i + 1) : path;
  }
  function categoryOf(filename) {
    const ext = (filename.match(/\.([a-z0-9]{1,8})$/i) || [])[1];
    const e = (ext || "").toLowerCase();
    if (["zip", "rar", "7z", "tar", "gz", "bz2", "xz"].includes(e)) return "archive";
    if (["jpg", "jpeg", "png", "gif", "webp", "svg", "bmp", "ico"].includes(e)) return "image";
    if (["mp4", "mkv", "webm", "avi", "mov", "flv", "wmv"].includes(e)) return "video";
    if (["mp3", "wav", "ogg", "flac", "m4a", "aac"].includes(e)) return "audio";
    if (["pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "md", "csv"].includes(e)) return "doc";
    return "other";
  }
  function percentOf(item) {
    if (!item || !item.total || item.total <= 0) return null;
    const p = Math.round((item.bytesReceived || 0) / item.total * 100);
    return Math.max(0, Math.min(100, p));
  }
  var DEFAULT_FOLDERS = Object.freeze({
    image: "Images",
    video: "Video",
    audio: "Audio",
    doc: "Documents",
    archive: "Archives",
    other: "Other"
  });
  function safeSegment(name) {
    const s = String(name || "").replace(/[\\/:*?"<>|]/g, "").replace(/\.\.+/g, "").trim();
    return s.slice(0, 60);
  }

  // src/license.js
  var PUBLIC_KEY_RAW_B64 = "BLRbHgtraYueEQa8+8xYcwMCqHOQ/8ujCjYpxwyi/HSyDoAyE0w7spKLZSYcQ9cc50fnrBn94Ua/kjlEDmlRSv4=";
  function b64urlToBytes(s) {
    const b64 = s.replace(/-/g, "+").replace(/_/g, "/");
    const pad = b64.length % 4 === 0 ? "" : "=".repeat(4 - b64.length % 4);
    const bin = atob(b64 + pad);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  async function verifyLicense(keyText) {
    try {
      const key = String(keyText || "").trim();
      const dot = key.indexOf(".");
      if (dot <= 0 || dot === key.length - 1) return null;
      const idPart = key.slice(0, dot);
      const sigPart = key.slice(dot + 1);
      const idBytes = b64urlToBytes(idPart);
      const idText = new TextDecoder().decode(idBytes);
      if (!idText.startsWith("TDPRO-")) return null;
      const sigBytes = b64urlToBytes(sigPart);
      const rawPub = b64urlToBytes(PUBLIC_KEY_RAW_B64);
      const cryptoKey = await crypto.subtle.importKey(
        "raw",
        rawPub,
        { name: "ECDSA", namedCurve: "P-256" },
        false,
        ["verify"]
      );
      const ok = await crypto.subtle.verify(
        { name: "ECDSA", hash: "SHA-256" },
        cryptoKey,
        sigBytes,
        idBytes
      );
      if (!ok) return null;
      return new TextDecoder().decode(idBytes);
    } catch {
      return null;
    }
  }

  // src/popup.js
  var $ = (sel) => document.querySelector(sel);
  var listEl = $("#list");
  var emptyEl = $("#empty");
  var modalEl = $("#modal");
  var DEFAULTS = {
    theme: "auto",
    filter: "all",
    shelf: false,
    pro: false,
    licenseId: "",
    organize: "off",
    dateFormat: "month",
    folders: {}
  };
  var prefs = { ...DEFAULTS };
  var items = [];
  var pendingConfirm = null;
  async function loadPrefs() {
    try {
      const stored = await chrome.storage.local.get(Object.keys(DEFAULTS));
      prefs = { ...DEFAULTS, ...stored };
    } catch {
      prefs = { ...DEFAULTS };
    }
  }
  async function savePrefs() {
    try {
      await chrome.storage.local.set(prefs);
      if (chrome.runtime?.sendMessage) {
        chrome.runtime.sendMessage({ type: "prefs-updated" }, () => void chrome.runtime.lastError);
      }
    } catch {
    }
  }
  function applyTheme() {
    const root = $("#app");
    const dark = prefs.theme === "dark" || prefs.theme === "auto" && window.matchMedia("(prefers-color-scheme: dark)").matches;
    root.dataset.theme = dark ? "dark" : "light";
    $("#btn-theme").textContent = prefs.theme.charAt(0).toUpperCase() + prefs.theme.slice(1);
  }
  async function cycleTheme() {
    const order = ["auto", "light", "dark"];
    prefs.theme = order[(order.indexOf(prefs.theme) + 1) % order.length];
    applyTheme();
    await savePrefs();
  }
  async function refresh() {
    try {
      items = await chrome.downloads.search({ orderBy: ["-startTime"], limit: 1e3 });
    } catch {
      items = [];
    }
    render();
  }
  function chip(name) {
    const el = document.createElement("span");
    el.className = "td-fileicon";
    el.textContent = name.slice(0, 4);
    return el;
  }
  var ICONS = {
    open: [["path", { d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" }], ["polyline", { points: "15 3 21 3 21 9" }], ["line", { x1: "10", y1: "14", x2: "21", y2: "3" }]],
    folder: [["path", { d: "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" }]],
    trash: [["polyline", { points: "3 6 5 6 21 6" }], ["path", { d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" }]],
    pause: [["rect", { x: "6", y: "4", width: "4", height: "16" }], ["rect", { x: "14", y: "4", width: "4", height: "16" }]],
    play: [["polygon", { points: "5 3 19 12 5 21 5 3" }]],
    retry: [["polyline", { points: "1 4 1 10 7 10" }], ["path", { d: "M3.51 15a9 9 0 1 0 2.13-9.36L1 10" }]],
    x: [["line", { x1: "18", y1: "6", x2: "6", y2: "18" }], ["line", { x1: "6", y1: "6", x2: "18", y2: "18" }]]
  };
  var SVG_NS = "http://www.w3.org/2000/svg";
  var ICON_FOR_LABEL = { Open: "open", "Show in folder": "folder", Delete: "trash", Pause: "pause", Resume: "play", Cancel: "x", Retry: "retry" };
  function icon(name) {
    const svg = document.createElementNS(SVG_NS, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("fill", "none");
    svg.setAttribute("stroke", "currentColor");
    svg.setAttribute("stroke-width", "2");
    svg.setAttribute("stroke-linecap", "round");
    svg.setAttribute("stroke-linejoin", "round");
    svg.setAttribute("aria-hidden", "true");
    for (const [tag, attrs] of ICONS[name]) {
      const el = document.createElementNS(SVG_NS, tag);
      for (const k in attrs) el.setAttribute(k, attrs[k]);
      svg.appendChild(el);
    }
    return svg;
  }
  var ERROR_LABELS = {
    USER_CANCELED: "Canceled by you",
    USER_SHUTDOWN: "Stopped (browser closed)",
    NETWORK_FAILED: "Network error",
    NETWORK_TIMEOUT: "Network timeout",
    NETWORK_INVALID_REQUEST: "Invalid request",
    SERVER_FAILED: "Server error",
    SERVER_FORBIDDEN: "Server refused (403)",
    SERVER_UNAUTHORIZED: "Authorization required (401)",
    SERVER_BAD_CONTENT: "File not found on server (404)",
    FILE_FAILED: "Could not save file",
    FILE_ACCESS_DENIED: "Access denied",
    FILE_NO_SPACE: "Not enough disk space",
    FILE_NAME_TOO_LONG: "File name too long",
    CRASH: "Download crashed"
  };
  function lowerFirstError(e) {
    return String(e).toLowerCase().replace(/_/g, " ");
  }
  function act(label, cls, onClick) {
    const b = document.createElement("button");
    b.className = `td-act ${cls || ""}`;
    b.appendChild(icon(ICON_FOR_LABEL[label] || "open"));
    b.title = label;
    b.setAttribute("aria-label", label);
    b.addEventListener("click", onClick);
    return b;
  }
  function stateLabel(item) {
    const bucket = bucketOf(item);
    if (bucket === "active") {
      const pct = percentOf(item);
      return pct === null ? "Downloading\u2026" : `Downloading ${pct}%`;
    }
    if (bucket === "done") return "Done";
    if (bucket === "failed") return `Failed${item.error ? `: ${ERROR_LABELS[item.error] || lowerFirstError(item.error)}` : ""}`;
    if (bucket === "stopped") return "Paused / stopped";
    return item.state;
  }
  function itemRow(item) {
    const row = document.createElement("div");
    row.className = "td-item";
    row.dataset.downloadId = String(item.id);
    const name = fileNameOf(item.filename);
    row.appendChild(chip(name));
    const main = document.createElement("div");
    main.className = "td-main";
    const nameEl = document.createElement("div");
    nameEl.className = "td-name";
    nameEl.textContent = name;
    main.appendChild(nameEl);
    const meta = document.createElement("div");
    meta.className = "td-meta";
    const bucket = bucketOf(item);
    meta.classList.add(`td-state-${bucket}`);
    const sizeTxt = item.state === "in_progress" && item.total ? `${formatBytes(item.bytesReceived)} / ${formatBytes(item.total)}` : formatBytes(item.total);
    meta.textContent = [stateLabel(item), sizeTxt, categoryOf(name)].filter(Boolean).join(" \xB7 ");
    main.appendChild(meta);
    if (bucket === "active") {
      const pct = percentOf(item);
      const bar = document.createElement("div");
      bar.className = "td-bar";
      const fill = document.createElement("i");
      fill.style.width = `${pct === null ? 4 : pct}%`;
      bar.appendChild(fill);
      main.appendChild(bar);
    }
    row.appendChild(main);
    const actions = document.createElement("div");
    actions.className = "td-actions";
    if (bucket === "active") {
      if (item.paused) {
        actions.appendChild(act("Resume", "", () => chrome.downloads.resume(item.id)));
        actions.appendChild(act("Cancel", "danger", () => chrome.downloads.cancel(item.id)));
      } else {
        actions.appendChild(act("Pause", "", () => chrome.downloads.pause(item.id)));
      }
    } else if (bucket === "done") {
      actions.appendChild(act("Open", "", () => chrome.downloads.open(item.id)));
      actions.appendChild(act("Show in folder", "", () => chrome.downloads.show(item.id)));
    } else if (bucket === "failed" || bucket === "stopped") {
      actions.appendChild(act("Retry", "", () => chrome.downloads.resume(item.id)));
      if (item.exists) {
        actions.appendChild(act("Open", "", () => chrome.downloads.open(item.id)));
      }
    }
    actions.appendChild(
      act("Delete", "danger", () => {
        pendingConfirm = { kind: "erase-one", id: item.id };
        openModal(`Remove \u201C${name}\u201D from the list? The file on disk is not touched.`);
      })
    );
    row.appendChild(actions);
    return row;
  }
  function render() {
    listEl.textContent = "";
    const visible = applyFilter(items, prefs.filter);
    emptyEl.hidden = visible.length > 0;
    let lastDay = "";
    for (const item of visible) {
      const day = dayKey(item.startTime);
      if (day !== lastDay) {
        lastDay = day;
        const h = document.createElement("div");
        h.className = "td-day";
        h.textContent = day;
        listEl.appendChild(h);
      }
      listEl.appendChild(itemRow(item));
    }
    for (const chipEl of $("#filters").querySelectorAll(".td-chip")) {
      chipEl.setAttribute("aria-selected", String(chipEl.dataset.filter === prefs.filter));
    }
  }
  var FOLDER_LABELS = {
    image: "Images",
    video: "Video",
    audio: "Audio",
    doc: "Documents",
    archive: "Archives",
    other: "Other"
  };
  function showSettings(show) {
    $("#settings").hidden = !show;
    $("#filters").hidden = show;
    listEl.hidden = show;
    emptyEl.hidden = show ? true : items.length > 0;
  }
  function renderProBadge() {
    const badge = $("#pro-badge");
    badge.textContent = prefs.pro ? `Pro${prefs.licenseId ? " \xB7 " + prefs.licenseId : ""}` : "Free";
    badge.dataset.pro = String(!!prefs.pro);
  }
  function renderFolderInputs() {
    const wrap = $("#folder-list");
    wrap.textContent = "";
    const folders = { ...DEFAULT_FOLDERS, ...prefs.folders || {} };
    for (const key of Object.keys(FOLDER_LABELS)) {
      const row = document.createElement("label");
      row.className = "td-set-row";
      const label = document.createElement("span");
      label.className = "td-set-label";
      label.textContent = FOLDER_LABELS[key];
      const input = document.createElement("input");
      input.className = "td-input";
      input.type = "text";
      input.dataset.folder = key;
      input.value = safeSegment(folders[key]) || DEFAULT_FOLDERS[key];
      input.maxLength = 60;
      input.spellcheck = false;
      row.appendChild(label);
      row.appendChild(input);
      wrap.appendChild(row);
    }
  }
  function showProMsg(text, ok) {
    const el = $("#pro-msg");
    el.textContent = text;
    el.hidden = !text;
    el.dataset.ok = String(!!ok);
  }
  async function activateLicense() {
    const input = $("#license-input");
    const key = input.value.trim();
    showProMsg("Verifying\u2026", true);
    const id = await verifyLicense(key);
    if (!id) {
      showProMsg("Invalid license key. Check for typos \u2014 verification is offline and exact.", false);
      return;
    }
    prefs.pro = true;
    prefs.licenseId = id;
    await savePrefs();
    renderProBadge();
    renderFolderInputs();
    showProMsg(`Pro activated (${id}). Auto-organize is now available.`, true);
    syncSettingsControls();
  }
  function syncSettingsControls() {
    $("#org-enabled").checked = prefs.pro && prefs.organize !== "off";
    $("#org-mode").value = prefs.organize === "off" ? "type" : prefs.organize;
    $("#org-datefmt").value = prefs.dateFormat || "month";
    $("#row-datefmt").hidden = prefs.organize !== "date" && prefs.organize !== "type+date";
    for (const el of document.querySelectorAll("#settings input, #settings select, #settings button")) {
      if (el.id !== "btn-back" && el.id !== "btn-activate" && el.id !== "license-input") {
        el.disabled = !prefs.pro;
      }
    }
  }
  async function saveSettings() {
    prefs.organize = $("#org-enabled").checked ? $("#org-mode").value : "off";
    prefs.dateFormat = $("#org-datefmt").value;
    const folders = {};
    for (const input of document.querySelectorAll("#folder-list .td-input")) {
      folders[input.dataset.folder] = safeSegment(input.value) || DEFAULT_FOLDERS[input.dataset.folder];
    }
    prefs.folders = folders;
    await savePrefs();
    showProMsg("Rules saved. New downloads will use them.", true);
  }
  function openModal(bodyText) {
    $("#modal-body").textContent = bodyText;
    $("#modal-ok").textContent = pendingConfirm?.kind === "erase-all" ? "Erase all" : "Remove";
    modalEl.hidden = false;
  }
  function closeModal() {
    pendingConfirm = null;
    modalEl.hidden = true;
  }
  async function confirmAction() {
    if (!pendingConfirm) return closeModal();
    try {
      if (pendingConfirm.kind === "erase-all") {
        await chrome.downloads.erase({});
      } else {
        await chrome.downloads.erase({ id: pendingConfirm.id });
      }
    } catch {
    }
    closeModal();
    await refresh();
  }
  $("#btn-theme").addEventListener("click", cycleTheme);
  $("#btn-clear").addEventListener("click", () => {
    pendingConfirm = { kind: "erase-all" };
    openModal("Erase the ENTIRE download history list? Files on disk are not deleted.");
  });
  $("#modal-cancel").addEventListener("click", closeModal);
  $("#modal-ok").addEventListener("click", confirmAction);
  modalEl.addEventListener("click", (e) => {
    if (e.target === modalEl) closeModal();
  });
  $("#filters").addEventListener("click", async (e) => {
    const chipEl = e.target.closest(".td-chip");
    if (!chipEl) return;
    prefs.filter = chipEl.dataset.filter;
    await savePrefs();
    render();
  });
  $("#btn-settings").addEventListener("click", () => {
    renderProBadge();
    renderFolderInputs();
    syncSettingsControls();
    showProMsg("", false);
    showSettings(true);
  });
  $("#btn-back").addEventListener("click", () => showSettings(false));
  $("#btn-activate").addEventListener("click", activateLicense);
  $("#btn-save-settings").addEventListener("click", saveSettings);
  $("#org-mode").addEventListener("change", syncSettingsControls);
  $("#org-enabled").addEventListener("change", syncSettingsControls);
  chrome.downloads.onCreated.addListener(refresh);
  chrome.downloads.onChanged.addListener(refresh);
  chrome.downloads.onErased.addListener(refresh);
  (async function init() {
    await loadPrefs();
    applyTheme();
    renderProBadge();
    renderFolderInputs();
    syncSettingsControls();
    render();
    await refresh();
  })();
})();
